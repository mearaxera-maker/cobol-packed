# HostLens Schema Workflow Release Design

## Summary

This release turns HostLens from a strong decoder into a practical schema
workflow tool. The current 1.0 release can decode and audit schema v2 records,
but users still have to hand-write schemas, hand-review schema drift, and hand
translate record layouts into application code. That is a real adoption gap for
migration teams.

The schema workflow release adds three command families:

- `hostlens schema from-copybook`
- `hostlens schema emit-rust`
- `hostlens schema compare`

This is still not a COBOL converter. It is a controlled bridge from common
copybook record declarations to HostLens schema v2, plus tools to review and
consume those schemas.

The design intentionally handles more than the happy path. COBOL copybooks are
messy: fixed columns, continuation lines, dialect-specific binary widths,
`REDEFINES`, `OCCURS`, signed display overpunch, missing copy members, filler
bytes with business meaning, and non-obvious alignment rules. The first
implementation must not guess through these cases. It should generate a schema
only when layout is defensible, and otherwise produce actionable diagnostics.

## Product Position

HostLens should sell as a forensic data-layout tool, not as a COBOL compiler
front end.

The schema workflow release should let a migration engineer:

1. Point HostLens at a straightforward copybook.
2. Produce a schema v2 draft.
3. Validate it against records.
4. Generate Rust adapter code or constants.
5. Compare future schema versions in CI.

The release should not imply:

- full COBOL dialect support;
- support for arbitrary copybook libraries;
- semantic understanding of COBOL programs;
- automatic handling of overlays, variable arrays, or compiler-dependent
  padding.

## Goals

- Bootstrap schema v2 from a limited, documented copybook subset.
- Preserve enough provenance to review generated schemas against original COBOL.
- Catch unsafe copybook constructs early with line-numbered diagnostics.
- Make schema drift reviewable in CI and code review.
- Generate Rust source that is useful without being unsafe or misleading.
- Keep the existing decode, verify, audit, and packaging behavior stable.
- Leave room for later support for overlays, arrays, SQL/Parquet, Python, and
  Wasm without forcing those designs now.

## Non-Goals

- Full COBOL grammar.
- Procedure division conversion.
- `COPY REPLACING` expansion.
- Dialect-specific compiler directive interpretation.
- `REDEFINES` runtime view generation in the first release.
- `OCCURS DEPENDING ON` active-length logic.
- `SYNC` padding inference.
- DBCS/NATIONAL field generation from copybook syntax.
- Unsafe Rust structs mapped over raw bytes.
- A new public Rust schema API unless needed by CLI internals.

## Release Shape

Recommended version: **1.1.0**.

Reason: this is additive CLI surface, not a patch. It should not change 1.0
decode semantics. Existing schemas and commands must continue to pass unchanged.

Release notes must clearly say:

- copybook support is a bootstrap feature;
- unsupported constructs are intentionally rejected or warned;
- generated schema should be reviewed before production use;
- HostLens still decodes data records, not COBOL programs.

## Commands

### `schema from-copybook`

```text
hostlens schema from-copybook \
  --copybook customer.cpy \
  --record-name CUSTOMER-RECORD \
  --encoding cp037 \
  --output customer.schema.json
```

Purpose: parse a limited copybook subset and emit a schema v2 fixed-width
layout.

Arguments:

- `--copybook <path>`: required input file.
- `--record-name <name>`: optional 01-level record selection.
- `--encoding <codepage>`: required default encoding for generated
  `display-text` fields.
- `--input-encoding binary|hex`: schema input encoding, default `binary`.
- `--on-error fail|skip-record|emit-error-row`: schema default, default
  `emit-error-row`.
- `--verification-scope field|record`: schema default, default `field`.
- `--output <path>`: write JSON to a file. Without it, write JSON to stdout.
- `--diagnostics json|text`: diagnostics format, default `text`.
- `--strict`: fail on any warning, not just blocking errors.
- `--include-fillers`: include generated filler ranges, default true.
- `--drop-fillers`: suppress filler entries when users only want business
  fields. This is incompatible with `verification_scope=record` unless all
  bytes are covered by fields.

Output contract:

- stdout contains only schema JSON when no `--output` path is given.
- diagnostics go to stderr.
- when `--diagnostics json` is set, diagnostics are newline-delimited JSON
  objects on stderr.
- exit code `0` means a schema was generated and validated.
- exit code `2` means schema/copybook/configuration failure.

### `schema emit-rust`

```text
hostlens schema emit-rust \
  --schema customer.schema.json \
  --struct-name CustomerRecord \
  --output customer_record.rs
```

Purpose: generate Rust source that helps application teams consume a decoded
HostLens schema.

Arguments:

- `--schema <path>`: required schema JSON/TOML.
- `--struct-name <Name>`: required Rust type name.
- `--module-name <name>`: optional module name comment/header.
- `--output <path>`: optional destination; stdout when omitted.
- `--derive debug,clone,serde`: optional derive set.
- `--raw-slices`: generate offset/length constants and raw slice accessor
  stubs in addition to decoded-value structs.
- `--visibility pub|pub(crate)|private`: default `pub`.

Generated style:

- no `unsafe`;
- no `#[repr(C)]`;
- no claim that Rust memory layout equals COBOL storage;
- one decoded-value struct;
- constants for fixed-width offsets and lengths;
- comments that preserve HostLens field type, encoding, scale, and source
  description;
- sanitized Rust identifiers with collision suffixes.

### `schema compare`

```text
hostlens schema compare --old old.json --new new.json --output table
hostlens schema compare --old old.json --new new.json --output json
```

Purpose: compare schemas semantically for code review and CI.

Arguments:

- `--old <path>`: required baseline schema.
- `--new <path>`: required candidate schema.
- `--output table|json|jsonl`: default `table`.
- `--fail-on warning|breaking|any|never`: default `any`.
- `--ignore-order`: compare fields by name only, even if order changes.
- `--show-unchanged`: include unchanged fields in machine output.

Exit codes:

- `0`: no relevant diff, or diff did not meet `--fail-on`.
- `1`: valid schemas differ and diff meets `--fail-on`.
- `2`: invalid schema or CLI configuration.
- `3`: I/O error.
- `4`: internal error.

## Copybook Input Model

The parser should support fixed-format and free-format declarations enough for
common copybooks.

Preprocessing steps:

1. Preserve original file bytes for diagnostics.
2. Normalize line endings.
3. Strip sequence area columns for fixed-format lines when present.
4. Ignore comment lines:
   - `*` or `/` in column 7 for fixed format;
   - lines beginning with `*>` after trimming.
5. Join continuation lines conservatively.
6. Stop each declaration at `.`.
7. Preserve original declaration text and source line span.

Known trap: copybooks often mix fixed and free format. The preprocessor should
avoid destructive column stripping when the file clearly looks free-format.
Heuristic mistakes here can change field names or PIC clauses. Diagnostics
should report which format was inferred.

## Supported Copybook Subset

Supported records:

- level `01` group records;
- nested group levels for name hierarchy and offset accumulation;
- elementary fields with `PIC` and optional `USAGE`;
- `FILLER`;
- period-terminated declarations.

Supported pictures:

- `PIC X(n)`
- `PIC A(n)`
- `PIC 9(n)`
- `PIC S9(n)`
- `PIC 9(n)V9(m)`
- `PIC S9(n)V9(m)`
- repeated character form such as `PIC 999V99`

Supported usage:

- implicit `DISPLAY`;
- `USAGE DISPLAY`;
- `COMP-3`;
- `PACKED-DECIMAL`;
- `COMP`;
- `BINARY`;
- `COMP-4`.

Generated field mapping:

| COBOL | Schema Field Type | Notes |
|---|---|---|
| `PIC X(n)` | `display-text` | uses `--encoding` |
| `PIC A(n)` | `display-text` | alphabetic only is not enforced at decode time |
| unsigned display `9` | `zoned-decimal` | EBCDIC zoned bytes |
| signed display `S9` | `zoned-decimal` | overpunch model, not separate sign |
| `COMP-3` | `packed-decimal` | byte length from digit count |
| `PACKED-DECIMAL` | `packed-decimal` | same as COMP-3 |
| `COMP` / `BINARY` / `COMP-4` | `binary` | IBM big-endian width assumptions |
| `FILLER PIC X(n)` | filler | unless `--drop-fillers` |

## Explicitly Unsupported In First Release

Blocking errors:

- `REDEFINES`
- `OCCURS`
- `OCCURS DEPENDING ON`
- `SYNC` / `SYNCHRONIZED`
- `JUSTIFIED`
- `SIGN IS SEPARATE`
- `BLANK WHEN ZERO`
- edited pictures, e.g. `ZZZ,ZZ9.99`
- national fields, e.g. `PIC N`
- `DISPLAY-1`
- level `66`
- level `77`
- level `88`
- compiler directives;
- `COPY` or `COPY REPLACING`;
- multiple 01 records without `--record-name`.

Non-blocking warnings in non-strict mode:

- unknown clauses that do not affect storage in the supported subset;
- group names that only exist for hierarchy;
- duplicate sanitized names that require suffixes;
- generated filler names.

Important policy: unsupported constructs should not silently become
`raw-bytes`. That would hide layout uncertainty. `raw-bytes` may be generated
only for explicitly safe filler or opaque byte ranges.

## Layout Engine

The layout engine should work from a small AST:

- `Copybook`
- `Record`
- `Group`
- `Elementary`
- `Diagnostic`
- `Picture`
- `Usage`

Each parsed elementary item should keep:

- original name;
- sanitized schema name;
- level;
- source line span;
- original declaration text;
- picture kind;
- usage;
- signed flag;
- total digits;
- scale;
- storage length;
- computed offset;
- generated field type;
- warning list.

Offset calculation rules:

- groups do not consume bytes directly;
- elementary fields consume bytes in declaration order;
- child offsets are absolute record offsets;
- `FILLER` consumes bytes and becomes a filler unless dropped;
- packed decimal length is `(digits + 2) / 2`;
- zoned decimal length is total digit count;
- display text length is picture character count;
- binary width uses IBM assumptions:
  - 1-4 digits: 2 bytes;
  - 5-9 digits: 4 bytes;
  - 10-18 digits: 8 bytes.

Potential bug: COBOL `COMP` width is dialect- and compiler-option-dependent.
The generated schema should include a description note saying the binary width
uses IBM mainframe assumptions. Future work can add `--binary-sizing ibm|native`
if needed.

Potential bug: signed display fields depend on codepage overpunch behavior.
HostLens currently models zoned decimal at the nibble level. This works for
common EBCDIC overpunch bytes but should be called out in diagnostics when the
source encoding is not EBCDIC.

Potential bug: `PIC S9(3)V99 COMP-3` has five digits, not three. The picture
parser must count both sides of `V`.

Potential bug: nested group names may create long schema names. The sanitizer
must cap names to the existing schema limit and add stable suffixes without
colliding.

## Name Normalization

COBOL names:

- uppercase by convention;
- may contain hyphens;
- may duplicate under different groups;
- may include `FILLER` repeatedly.

Schema names:

- lowercase ASCII;
- hyphen converted to underscore by default;
- group path may be prefixed when needed for uniqueness;
- duplicate names get deterministic suffixes: `_2`, `_3`, etc.;
- original names are preserved in `description`.

Rust identifiers:

- snake_case for fields;
- SCREAMING_SNAKE_CASE for constants;
- reserved words get trailing underscore;
- invalid leading digits get a leading underscore;
- collisions are resolved deterministically.

Potential bug: schema names currently allow hyphen and dot, but Rust does not.
`emit-rust` must not reuse schema names blindly.

## Diagnostics

Diagnostics should be first-class output, not incidental strings.

Fields:

- `severity`: `warning` or `error`;
- `code`: stable diagnostic code, e.g. `C_COPYBOOK_REDEFINES`;
- `line`;
- `column` when known;
- `record_name`;
- `field_name`;
- `message`;
- `help`;
- `source`.

Text diagnostics example:

```text
C_COPYBOOK_REDEFINES error line 12 field ALT-AMOUNT: REDEFINES overlays are not supported by schema from-copybook
help: model this copybook by hand as separate schemas or wait for overlay support
```

JSON diagnostic example:

```json
{"severity":"error","code":"C_COPYBOOK_REDEFINES","line":12,"field_name":"ALT-AMOUNT","message":"REDEFINES overlays are not supported"}
```

Potential bug: diagnostics on stdout would corrupt generated schema JSON. All
diagnostics must go to stderr unless the command is explicitly diagnostic-only.

## Generated Schema Provenance

Each generated field description should include provenance:

- original COBOL name;
- source line number;
- original PIC clause;
- original USAGE clause;
- any assumption, e.g. IBM binary sizing.

Example description:

```text
COBOL: CUSTOMER-AMOUNT line 8 PIC S9(7)V99 COMP-3
```

This intentionally stays in `description`, so it does not affect semantic hash.

Potential bug: if provenance is placed in semantic fields instead of
`description`, schema hashes will churn when comments or line numbers change.

## Schema Compare Semantics

`schema compare` should compare the same semantic projection used for schema
hashing, plus structured diff metadata for humans.

Ignored:

- `description`;
- schema `output`;
- JSON/TOML formatting;
- field order when `--ignore-order` is set.

Compared:

- schema version;
- record length;
- input encoding;
- `on_error`;
- verification scope;
- field names;
- field offsets;
- field lengths;
- field types;
- encodings;
- digit count;
- scale;
- signedness;
- sign mode;
- field mode;
- required flag;
- filler names, offsets, and lengths;
- coverage summary.

Diff severity:

- `breaking`: removed fields, type changes, offset changes, length changes,
  record length changes, encoding changes, signedness changes.
- `warning`: added fields, added fillers, verification-scope changes,
  `on_error` changes.
- `info`: description/output-only differences, if shown at all.

Potential bug: comparing fields only by array index will produce noisy diffs
when one field is inserted near the top. Default should match by field name and
also report order changes separately for fixed-width schemas.

Potential bug: two fields can swap names while keeping offsets. Compare should
report both name and offset perspectives so reviewers can catch accidental
renames.

## Rust Emission Semantics

Generated Rust should be intentionally boring.

Example:

```rust
pub const RECORD_LEN: usize = 16;
pub const ACCOUNT_OFFSET: usize = 0;
pub const ACCOUNT_LEN: usize = 4;

#[derive(Debug, Clone)]
pub struct CustomerRecord {
    pub account: String,
    pub amount: String,
    pub sequence: u64,
    pub flags: Vec<u8>,
}
```

No parser implementation is required in the first release. The generated file is
a stable interop scaffold and documentation artifact.

Potential bug: generating decimal fields as numeric Rust types would imply
precision/range choices HostLens does not own. Use `String` for decimal text in
the first release.

Potential bug: adding serde derives unconditionally adds dependency assumptions.
Only emit serde derives when requested.

Potential bug: generated code can fail to compile due reserved words. Keep a
small Rust keyword table in the generator.

## Internal Modules

Add:

- `src/cli/copybook.rs`
- `src/cli/schema_emit.rs`
- `src/cli/schema_compare.rs`

Update:

- `src/cli/args.rs` for new subcommands and argument structs.
- `src/cli/mod.rs` for dispatch only.
- `src/cli/schema.rs` only where existing structs need constructors/helpers.
- `src/cli/render.rs` only if compare rendering shares existing table/JSON
  helpers.

Avoid:

- putting parser logic in `mod.rs`;
- adding copybook parsing into `schema.rs`;
- making generated Rust depend on internal HostLens modules;
- introducing heavy dependencies for this release.

## Test Matrix

Copybook generation:

- simple record with `PIC X`, `PIC 9`, `PIC S9V99`, `COMP-3`, `COMP`, and
  `FILLER`;
- nested groups flatten into unique field names;
- generated offsets and record length match expected byte layout;
- generated schema validates with `schema check`;
- `--drop-fillers` works but rejects record verification scope if coverage
  would be incomplete;
- multiple 01 records require `--record-name`;
- fixed-format comments and free-format comments are ignored;
- repeated character pictures and `(n)` pictures produce the same layout.

Unsupported constructs:

- `REDEFINES` fails with line number;
- `OCCURS` fails with line number;
- `SYNC` fails with line number;
- level 88 fails with line number;
- `SIGN IS SEPARATE` fails with line number;
- `COPY` fails with a message that expansion is not implemented.

Rust emission:

- struct name validation;
- snake_case field conversion;
- reserved word escaping;
- duplicate identifier suffixing;
- constants for fixed-width fields;
- no `unsafe` and no `repr(C)`;
- optional serde derive only when requested.

Schema compare:

- identical schemas exit 0;
- descriptions/output-only differences exit 0;
- field type change exits 1;
- offset change exits 1;
- added field severity is warning;
- JSON output is stable and parseable;
- `--fail-on breaking` does not fail on warning-only diffs;
- invalid schema exits 2.

Regression:

- all existing 1.0 CLI tests keep passing;
- schema hash tests keep passing;
- package excludes still exclude generated dist artifacts.

## Risk Register

| Risk | Impact | Mitigation |
|---|---|---|
| Miscomputed copybook offset | Silent data corruption | validate generated schema, test layout matrix, emit provenance |
| Dialect-specific COMP width | Wrong binary values | document IBM assumption, include warning in description |
| Fixed/free format heuristic wrong | Parser misses declarations | report inferred format, keep strict diagnostics |
| Unsupported overlay guessed as fields | False schema confidence | fail `REDEFINES` in first release |
| Arrays treated as one field | Wrong record length | fail `OCCURS` in first release |
| Generated Rust implies zero-copy layout | Unsafe adoption | no `repr(C)`, no raw struct mapping |
| Compare produces noisy diffs | CI unusable | match by field name and classify severity |
| Diagnostics corrupt stdout JSON | Broken automation | diagnostics always stderr |
| New deps bloat CLI | Packaging risk | avoid heavy deps in schema workflow release |

## Future Extensions

After this release, the natural next steps are:

- controlled `OCCURS n TIMES` expansion;
- `REDEFINES` alternate views;
- `schema from-copybook --copy-dir` with COPY member resolution;
- `--binary-sizing ibm|micro-focus|native`;
- SQL output;
- Parquet output;
- Python bindings;
- Wasm package.

Those should not be mixed into the first schema workflow implementation.
