from __future__ import annotations

import importlib
import json
import sys
import tempfile
import types
import unittest
from pathlib import Path


class FakeClickCommand:
    def __init__(self, func):
        self.func = func

    def __call__(self, *args, **kwargs):
        return self.func(*args, **kwargs)

    def command(self, *_args, **_kwargs):
        return lambda func: FakeClickCommand(func)

    def group(self, *_args, **_kwargs):
        return lambda func: FakeClickCommand(func)


def fake_click_module() -> types.SimpleNamespace:
    class ClickException(Exception):
        pass

    class PathType:
        def __init__(self, *_args, **_kwargs):
            pass

    def identity_decorator(*_args, **_kwargs):
        return lambda func: func

    return types.SimpleNamespace(
        ClickException=ClickException,
        Path=PathType,
        argument=identity_decorator,
        command=identity_decorator,
        group=lambda *_args, **_kwargs: lambda func: FakeClickCommand(func),
        option=identity_decorator,
        echo=lambda *_args, **_kwargs: None,
        secho=lambda *_args, **_kwargs: None,
        progressbar=lambda items, **_kwargs: items,
    )


def scratch_root(name: str) -> Path:
    path = Path(tempfile.mkdtemp(prefix=f"cobol-python-{name}-"))
    path.mkdir(parents=True, exist_ok=True)
    return path


class CliTests(unittest.TestCase):
    def test_cli_module_imports_without_native_extension(self) -> None:
        previous_click = sys.modules.get("click")
        sys.modules["click"] = fake_click_module()
        previous = sys.modules.pop("cobol_converter._native", None)
        sys.modules.pop("cobol_converter.cli", None)
        try:
            module = importlib.import_module("cobol_converter.cli")
            self.assertTrue(hasattr(module, "main"))
        finally:
            sys.modules.pop("cobol_converter.cli", None)
            if previous_click is None:
                sys.modules.pop("click", None)
            else:
                sys.modules["click"] = previous_click
            if previous is not None:
                sys.modules["cobol_converter._native"] = previous

    def test_check_uses_shared_converter_config(self) -> None:
        previous_click = sys.modules.get("click")
        sys.modules["click"] = fake_click_module()
        fake = types.SimpleNamespace()
        calls: list[tuple[str, str, dict]] = []

        def check_cobol(source: str, dialect: str, options: dict) -> dict:
            calls.append((source, dialect, options))
            return {"ok": True, "diagnostics": [], "diagnostics_json": "[]"}

        def convert_cobol(_source: str, _dialect: str, _options: dict) -> dict:
            raise AssertionError("check command must not generate Rust")

        fake.check_cobol = check_cobol
        fake.convert_cobol = convert_cobol
        previous = sys.modules.get("cobol_converter._native")
        sys.modules["cobol_converter._native"] = fake
        sys.modules.pop("cobol_converter.cli", None)
        try:
            module = importlib.import_module("cobol_converter.cli")
            root = scratch_root("cli-config")
            source = root / "program.cbl"
            source.write_text("DISPLAY 'OK'.\n", encoding="utf-8")
            copybooks = root / "copybooks"
            copybooks.mkdir(exist_ok=True)
            (copybooks / "FIELDS.cpy").write_text("01 WS-FLAG PIC X.\n", encoding="utf-8")
            config = root / "cobol2rust.toml"
            config.write_text(
                """
[converter]
dialect = "ibm_zos"
source_format = "free"
copybook_dirs = ["copybooks"]
""",
                encoding="utf-8",
            )

            module.check(
                str(source),
                "ibm",
                "auto",
                (),
                True,
                str(config),
            )

            self.assertEqual(calls[0][1], "ibm_zos")
            self.assertEqual(calls[0][2]["source_format"], "free")
            self.assertEqual(calls[0][2]["copybooks"], {"FIELDS.cpy": "01 WS-FLAG PIC X.\n"})
        finally:
            sys.modules.pop("cobol_converter.cli", None)
            if previous_click is None:
                sys.modules.pop("click", None)
            else:
                sys.modules["click"] = previous_click
            if previous is None:
                sys.modules.pop("cobol_converter._native", None)
            else:
                sys.modules["cobol_converter._native"] = previous

    def test_batch_convert_can_verify_generated_project_builds(self) -> None:
        previous_click = sys.modules.get("click")
        sys.modules["click"] = fake_click_module()
        fake = types.SimpleNamespace()
        convert_calls: list[tuple[str, str, str, dict]] = []

        root = scratch_root("cli-batch-verify")
        source_dir = root / "cobol"
        source_dir.mkdir(parents=True, exist_ok=True)
        (source_dir / "payroll.cbl").write_text("DISPLAY 'PAY'.\n", encoding="utf-8")
        output_dir = root / "generated"
        summary = root / "reports" / "batch.json"
        summary.parent.mkdir(parents=True, exist_ok=True)

        def convert_project(source: str, dialect: str, output_dir_text: str, options: dict) -> str:
            convert_calls.append((source, dialect, output_dir_text, options))
            Path(output_dir_text).mkdir(parents=True, exist_ok=True)
            return (
                '{"out_dir": "'
                + output_dir_text.replace("\\", "\\\\")
                + '", "generated_files": [], "report_path": "report.json", "diagnostics": []}'
            )

        fake.convert_project = convert_project
        previous = sys.modules.get("cobol_converter._native")
        sys.modules["cobol_converter._native"] = fake
        sys.modules.pop("cobol_converter.cli", None)
        try:
            module = importlib.import_module("cobol_converter.cli")
            run_calls: list[tuple[list[str], str]] = []

            def fake_run(command, cwd, text, stdout, stderr, check):
                run_calls.append((list(command), str(cwd)))
                return types.SimpleNamespace(returncode=0, stdout="ok", stderr="")

            module.subprocess.run = fake_run

            module.batch_convert(
                str(source_dir),
                str(output_dir),
                None,
                "ibm",
                "free",
                (),
                str(summary),
                None,
                False,
                True,
            )

            report = __import__("json").loads(summary.read_text(encoding="utf-8"))
            self.assertEqual(report["generated"], 1)
            self.assertEqual(report["failures"], 0)
            self.assertEqual(report["projects"][0]["build"]["passed"], True)
            self.assertEqual(run_calls[0][0], ["cargo", "check", "--offline"])
            self.assertTrue(run_calls[0][1].endswith("generated\\payroll"))
            self.assertEqual(convert_calls[0][1], "ibm")
        finally:
            sys.modules.pop("cobol_converter.cli", None)
            if previous_click is None:
                sys.modules.pop("click", None)
            else:
                sys.modules["click"] = previous_click
            if previous is None:
                sys.modules.pop("cobol_converter._native", None)
            else:
                sys.modules["cobol_converter._native"] = previous

    def test_batch_convert_uses_config_copybook_dirs_relative_to_config(self) -> None:
        previous_click = sys.modules.get("click")
        sys.modules["click"] = fake_click_module()
        fake = types.SimpleNamespace()
        convert_calls: list[tuple[str, str, str, dict]] = []

        root = scratch_root("cli-batch-config-copybooks")
        source_dir = root / "cobol"
        source_dir.mkdir(parents=True, exist_ok=True)
        (source_dir / "payroll.cbl").write_text("COPY FIELDS.\n", encoding="utf-8")
        copybooks = root / "copybooks"
        copybooks.mkdir(exist_ok=True)
        (copybooks / "FIELDS.cpy").write_text("01 WS-FLAG PIC X.\n", encoding="utf-8")
        config = root / "cobol2rust.toml"
        config.write_text(
            """
[converter]
dialect = "ibm_zos"
source_format = "free"
copybook_dirs = ["copybooks"]
""",
            encoding="utf-8",
        )

        def convert_project(source: str, dialect: str, output_dir_text: str, options: dict) -> str:
            convert_calls.append((source, dialect, output_dir_text, options))
            Path(output_dir_text).mkdir(parents=True, exist_ok=True)
            return (
                '{"out_dir": "'
                + output_dir_text.replace("\\", "\\\\")
                + '", "generated_files": [], "report_path": "report.json", "diagnostics": []}'
            )

        fake.convert_project = convert_project
        previous = sys.modules.get("cobol_converter._native")
        sys.modules["cobol_converter._native"] = fake
        sys.modules.pop("cobol_converter.cli", None)
        try:
            module = importlib.import_module("cobol_converter.cli")
            summary = root / "reports" / "batch.json"

            module.batch_convert(
                str(source_dir),
                str(root / "generated"),
                str(config),
                "ibm",
                "auto",
                (),
                str(summary),
                None,
                False,
                False,
            )

            self.assertEqual(convert_calls[0][1], "ibm_zos")
            self.assertEqual(convert_calls[0][3]["source_format"], "free")
            self.assertEqual(convert_calls[0][3]["copybooks"], {"FIELDS.cpy": "01 WS-FLAG PIC X.\n"})
            self.assertTrue(summary.exists())
        finally:
            sys.modules.pop("cobol_converter.cli", None)
            if previous_click is None:
                sys.modules.pop("click", None)
            else:
                sys.modules["click"] = previous_click
            if previous is None:
                sys.modules.pop("cobol_converter._native", None)
            else:
                sys.modules["cobol_converter._native"] = previous

    def test_doctor_reports_tool_availability_and_docker_fallback(self) -> None:
        previous_click = sys.modules.get("click")
        sys.modules["click"] = fake_click_module()
        sys.modules.pop("cobol_converter.cli", None)
        try:
            module = importlib.import_module("cobol_converter.cli")

            def fake_which(name: str) -> str | None:
                return {"cargo": "C:/bin/cargo.exe", "docker": "C:/bin/docker.exe"}.get(name)

            previous_find_spec = module.importlib.util.find_spec
            module.shutil.which = fake_which
            module.importlib.util.find_spec = lambda _name: None

            report = module._doctor_report()

            self.assertEqual(report["tools"]["cargo"]["available"], True)
            self.assertEqual(report["tools"]["cargo"]["source"], "path")
            self.assertEqual(report["tools"]["maturin"]["available"], False)
            self.assertEqual(report["tools"]["cobc"]["available"], False)
            self.assertEqual(report["tools"]["docker"]["available"], True)
            self.assertEqual(report["ready"]["build_generated_rust"], True)
            self.assertEqual(report["ready"]["build_python_package"], False)
            self.assertEqual(report["ready"]["oracle_validation"], False)
            self.assertIn("docker build -f docker/python-toolkit/Dockerfile", report["docker"])

            output = scratch_root("doctor") / "doctor.json"
            output.parent.mkdir(parents=True, exist_ok=True)
            module.doctor(str(output))
            self.assertEqual(json.loads(output.read_text(encoding="utf-8")), report)
        finally:
            if "module" in locals():
                module.importlib.util.find_spec = previous_find_spec
            sys.modules.pop("cobol_converter.cli", None)
            if previous_click is None:
                sys.modules.pop("click", None)
            else:
                sys.modules["click"] = previous_click


if __name__ == "__main__":
    unittest.main()
