from __future__ import annotations

import sys
import types
import unittest

import cobol_converter


class PublicApiTests(unittest.TestCase):
    def test_public_api_delegates_convert_and_preprocess_to_native_extension(self) -> None:
        fake = types.SimpleNamespace()
        calls: list[tuple[str, tuple, dict]] = []

        def convert_cobol(source: str, dialect: str, options: dict) -> dict:
            calls.append(("convert_cobol", (source, dialect, options), {}))
            return {"ok": True, "rust": "pub struct Program;\n", "diagnostics": []}

        def check_cobol(source: str, dialect: str, options: dict) -> dict:
            calls.append(("check_cobol", (source, dialect, options), {}))
            return {"ok": True, "diagnostics": [], "diagnostics_json": "[]"}

        def preprocess(source: str, copybooks: dict, source_format: str = "auto") -> str:
            calls.append(("preprocess", (source, copybooks, source_format), {}))
            return "expanded"

        fake.convert_cobol = convert_cobol
        fake.check_cobol = check_cobol
        fake.preprocess = preprocess
        previous = sys.modules.get("cobol_converter._native")
        sys.modules["cobol_converter._native"] = fake
        try:
            self.assertEqual(
                cobol_converter.convert_cobol("DISPLAY 'X'.", "ibm_zos", {}),
                {
                    "ok": True,
                    "rust": "pub struct Program;\n",
                    "diagnostics": [],
                },
            )
            self.assertEqual(
                cobol_converter.check_cobol("DISPLAY 'X'.", "ibm_zos", {}),
                {"ok": True, "diagnostics": [], "diagnostics_json": "[]"},
            )
            self.assertEqual(
                cobol_converter.preprocess(
                    "COPY REC.", {"REC.cpy": "01 X PIC X."}, source_format="free"
                ),
                "expanded",
            )
            self.assertEqual(
                calls,
                [
                    ("convert_cobol", ("DISPLAY 'X'.", "ibm_zos", {}), {}),
                    ("check_cobol", ("DISPLAY 'X'.", "ibm_zos", {}), {}),
                    ("preprocess", ("COPY REC.", {"REC.cpy": "01 X PIC X."}, "free"), {}),
                ],
            )
        finally:
            if previous is None:
                sys.modules.pop("cobol_converter._native", None)
            else:
                sys.modules["cobol_converter._native"] = previous


if __name__ == "__main__":
    unittest.main()
