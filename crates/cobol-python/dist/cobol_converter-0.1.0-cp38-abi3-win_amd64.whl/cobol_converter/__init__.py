"""Python tooling for the COBOL-to-Rust converter."""

from __future__ import annotations

from importlib import import_module
from typing import Any

__all__ = [
    "__version__",
    "analyze_source",
    "batch_convert_sources",
    "check_cobol",
    "convert_cobol",
    "convert_project",
    "dependency_graph_dot",
    "preprocess",
]

__version__ = "0.1.0"


def _native_module() -> Any:
    return import_module("cobol_converter._native")


def preprocess(
    source: str,
    copybooks: dict[str, str] | None = None,
    *,
    source_format: str = "auto",
) -> str:
    """Expand COPY members from an in-memory copybook mapping."""
    return _native_module().preprocess(source, copybooks or {}, source_format=source_format)


def convert_cobol(source: str, dialect: str, options: dict[str, Any] | None = None) -> dict:
    """Convert COBOL source in memory and return Rust or structured diagnostics."""
    return _native_module().convert_cobol(source, dialect, options or {})


def check_cobol(source: str, dialect: str, options: dict[str, Any] | None = None) -> dict:
    """Validate COBOL source in memory without generating Rust output."""
    return _native_module().check_cobol(source, dialect, options or {})


def analyze_source(path: str, source: str) -> str:
    """Return converter source analysis as a JSON string."""
    return _native_module().analyze_source(path, source)


def dependency_graph_dot(path: str, source: str) -> str:
    """Return a DOT dependency graph for COPY and CALL relationships."""
    return _native_module().dependency_graph_dot(path, source)


def convert_project(
    source: str,
    dialect: str,
    output_dir: str,
    options: dict[str, Any] | None = None,
) -> str:
    """Convert source into a generated Rust project and return JSON metadata."""
    return _native_module().convert_project(source, dialect, output_dir, options or {})


def batch_convert_sources(
    sources: dict[str, str],
    dialect: str,
    output_dir: str,
    options: dict[str, Any] | None = None,
) -> str:
    """Convert multiple in-memory COBOL sources into generated project directories."""
    return _native_module().batch_convert_sources(sources, dialect, output_dir, options or {})
